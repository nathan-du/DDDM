/**
 * http://usejsdoc.org/
 */
$(document).ready(function(){
	alert("This is Hello World by JQuery");
});